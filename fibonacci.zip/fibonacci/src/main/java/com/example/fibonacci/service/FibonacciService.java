package com.example.fibonacci.service;

import com.example.fibonacci.log.Loggable;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.math.BigInteger;

@Service
public class FibonacciService {

    @Loggable
    @Cacheable(value = "fibonacci", key = "#input")
    public BigInteger fibonacci(String input) {
        int n;
        try {
            n = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Input must be a valid integer.", e);
        }

        if (n < 0) throw new IllegalArgumentException("Index cannot be negative");
        return computeIterative(n);
    }

    private BigInteger computeIterative(int n) {
        if (n == 0) return BigInteger.ZERO;
        if (n == 1) return BigInteger.ONE;

        BigInteger a = BigInteger.ZERO;
        BigInteger b = BigInteger.ONE;

        for (int i = 2; i <= n; i++) {
            BigInteger next = a.add(b);
            a = b;
            b = next;
        }

        return b;
    }
}

